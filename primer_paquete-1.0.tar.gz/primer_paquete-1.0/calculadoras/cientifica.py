import json

nombre = "Luis"

def tangente(num1):
    return num1


class Clase:
    pass